# Unity Theory website — start here

**Revision 3 · 1 October 2026 · Source-aligned planning handoff**

Use [UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md](UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md) as the **only forward implementation plan**. This replaces R2 instructions, not any real accepted implementation. [PROJECT_SOURCE_ALIGNMENT.md](PROJECT_SOURCE_ALIGNMENT.md) explains the current-versus-history relationship; it is an index, not another tracker.

## Scientific source comes first

The shared Project declares **RRG_CURRENT** the active scientific package. Start with its actual current manifest, locked core and change control, then the current explanation/framework/math/status/proof/evidence documents. Do not use the old v0.1b README or narrower audit objective as replacements.

**The actual RRG_CURRENT package is not included here.** The two shared Project attachments are notices with links. Their full visible text is transcribed under `source/project-notes/` with exact source IDs; they do not supply the current files. [SOURCE_AUTHORITY.json](SOURCE_AUTHORITY.json) records the expected main-file inventory and core pin, with actual hashes null and currentSourceQualified false.

## First Codex task

Read plan §0, §§1–4 (especially current-source admission §3.1a), M0 in §8, §9 verification and §10 prompts. The requested workflow is a Codex 6.1 Sol High implementation session and a separate fresh High review. No automatic/background session is implied.

Begin M0: preserve history, install source-intake checks and build a private static reading slice. Local scaffold/fixture work does not need a domain, remote account or completed scientific proof. Do not fabricate missing current documents to satisfy a validator. M1 real-current-content acceptance and actual-corpus publication require genuine current bytes and the manifest/core checks.

## Reader experience

Keep the introduction understandable with everyday examples, then deepen into precise definitions, equations and evidence. Preserve the environmental-enabling example and the shared effective-interaction-to-further-organization question. An analogy is not universal proof; the older model-reduction work is not a replacement for the project's meaning.

## Included and excluded

[BUNDLE_INFO.md](BUNDLE_INFO.md) describes fourteen byte-preserved historical research files, the two notice transcriptions, this aligned plan/source index and the original R2 ZIP with its historical evidence. It does **not** contain a complete verified current scientific package, an implemented website or new public deployment.

Run the handoff checks from this folder:

```sh
python evidence/alignment_checks.py
```

Those check this package and small source-admission reference cases, not the future production website. Results live in [evidence/ALIGNMENT_VALIDATION.json](evidence/ALIGNMENT_VALIDATION.json). No old numerical/website result is claimed as freshly run by this alignment.

Source-theory edits must follow the actual current change-control rules. Public repository/Pages publication, identity/rights choices and DNS changes still require real owner authorization.
