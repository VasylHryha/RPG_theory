# Unity Theory — shared sources and website alignment

**Revision 3 · 1 October 2026**  
**Role:** source and document index. The implementation plan remains the only execution tracker. This file does not replace the theory or amend its locked core.

## The correction

The shared Project notes designate **RRG_CURRENT as the only active scientific package**. The earlier website R2 handoff instead used five v0.1b documents and nine audit files as its scientific baseline. Those are useful historical sources, but they are not the declared current package.

The aligned handoff is [the R3 implementation plan](UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md). [START_HERE](START_HERE.md) gives Codex's execution route. [SOURCE_AUTHORITY.json](SOURCE_AUTHORITY.json) makes the current source-availability boundary explicit.

## What governs what

| Subject | Source of authority | Website responsibility |
|---|---|---|
| Locked meaning and scope | Actual RRG_CURRENT/00_LOCKED_CORE.md and explicit authorized later decisions | Preserve bytes/meaning; do not reconstruct from history |
| Source change rules | Actual RRG_CURRENT/05_CHANGE_CONTROL.md | Follow those rules rather than inventing a website-owned theory |
| Active edition and membership | Actual RRG_CURRENT/CURRENT_MANIFEST.md | Verify the coherent admitted package and record all actual member hashes |
| Current explanation/framework/math | Actual current 01/02/03 documents | Render original source through sidecars; write reviewed beginner explanations separately |
| Current research status and support | Actual current 04/06/07/08 documents | Preserve the distinction between definition, proposal, evidence and demonstrated result |
| Website architecture, tasks and acceptance | R3 implementation plan | One source-bound publication pipeline, M0–M7, separate implementation and review |
| Older drafts and calculations | Fourteen preserved older files and original R2 handoff | Explicit history or selected supporting work, never a silent current-source fallback |

Owner decisions define intended meanings and permissions. Arguments and evidence determine scientific support. Neither source priority nor the word “proof” in a filename certifies a claim.

## What the website must continue to explain

Start with familiar examples in ordinary language. Explain arrangement and activity, parts remaining active within a whole, persistent wholes participating in further organization, and structures changing the conditions for later organization. Only then introduce precise definitions, equations, scientific evidence and open tests.

The [shared extension note](source/project-notes/emergent-interaction-update-note.md) additionally reports the research connection:

**lower-level geometry/modes → effective interaction regime → possible further persistent organization.**

That connection belongs in the deeper explanation and evidence pages. The environmental/life example remains in the beginner journey. The website must not reduce the entire project to the older response-reduction audit, and it must not claim that the four fundamental forces have been proved to form four successive RRG levels.

The note names three evidence topics; the actual newer evidence files still need to be read and checked before their claims are published. No contents for `08_ADDITIONAL_PRIMARY_EVIDENCE.md` are invented in this handoff.

## Expected current source map

| Main file named by shared note | Use in the site | Availability in this alignment |
|---|---|---|
| 00_LOCKED_CORE.md | Exact source for core meanings and bound definitions | Actual file not obtained |
| 01_world_explanation.md | Beginner explanation source | Current version not obtained |
| 02_scientific_framework.md | Framework source | Current version not obtained |
| 03_mathematical_core.md | Mathematics source | Current version not obtained |
| 04_status_and_blockers.md | Current research status | Current version not obtained |
| 05_CHANGE_CONTROL.md | Theory change rules | Actual file not obtained |
| 06_PROOF_MATRIX.md | Claim-to-support/status mapping | Actual file not obtained |
| 07_EMERGENT_INTERACTION_EVIDENCE.md | Interaction-extension evidence | Actual file not obtained |
| 08_ADDITIONAL_PRIMARY_EVIDENCE.md | Additional primary evidence | Actual file not obtained |
| CURRENT_MANIFEST.md | Current package membership and edition | Actual file not obtained |

This is the note's list of **main files**, not a claim that the actual package contains exactly ten files. Complete membership must be checked against the real manifest.

## The locked-core pin

Both shared notes record:

```text
b6d3e7c75285889afe94cabf083ba5fb80f401c656613ba6a80d2f0149b655e1
```

This is an **expected** SHA-256. The actual core bytes were not available, so this alignment did not compute or verify that hash. R3 checks raw bytes before accepting a current package; a mismatch cannot automatically rewrite the expected value. Hash equality also does not prove scientific validity or that other files form a coherent edition.

## Source availability and what was changed

Both Project attachments named `GPT 6.1 overview.txt` were read by exact file ID. One designates the current package; the other reports the interaction-evidence update. They are short status notices containing links, not the package contents themselves.

The inspected workspace and accessible Files searches did not provide RRG_CURRENT.zip or its actual current members. Earlier sandbox links recorded inside a note do not establish a downloadable path in this session. The full older RRG archive named by the note is also not supplied.

**Changed:** complete website handoff/source-role mapping, current-source gate, record/route bindings, relevant milestones and prompts. **Not changed:** original Project note attachments, any locked-core bytes, current scientific documents, old research source bytes, public GitHub/website/DNS state or license.

The original R2 ZIP is retained [as superseded history](history/UNITY_THEORY_WEBSITE_HANDOFF_R2.zip). Its tests and numerical receipts remain historical. This revision does not repeat their execution claims as fresh results.

## Where the files go together

```text
research/RRG_CURRENT/    actual scientific source after verified intake
research/publication/   source adapters and new reviewed explanations/articles
research/history/       preserved older research, never current fallback
docs/plans/             one R3 website implementation plan
```

The site renders original current documents through sidecar metadata instead of adding frontmatter to the locked files or keeping a second editable framework. Definition records extract actual source statements; simpler explanations are separately reviewed derivatives. Download labels distinguish original source bytes from normalized explanatory exports.

M0 local engineering and fixture checks can proceed now. Actual-current-content acceptance and publication stay blocked until the genuine RRG_CURRENT package, including its manifest and locked core, is obtained and checked. Do not manufacture a “current” package from old files simply to clear that gate.

## Exact shared-note identities

[P-CURRENT-NOTE](source/project-notes/current-package-note.md): `file_0000000047a0820ab6beb4722417cd62`, title `GPT 6.1 overview.txt`. Designates RRG_CURRENT and lists the main files and expected hash.

[P-EXTENSION-NOTE](source/project-notes/emergent-interaction-update-note.md): `file_000000008550820ab37191709b2c050d`, same title. Reports the emergent-interaction extension and the unchanged-core claim, with a four-force limitation.

These included note files are labelled transcriptions, not claims of original-byte identity. Bibliographic and current-source statements retain their original verification limits.
