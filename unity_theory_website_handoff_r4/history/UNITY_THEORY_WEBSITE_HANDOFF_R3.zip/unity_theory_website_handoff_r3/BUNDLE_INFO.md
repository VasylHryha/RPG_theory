# Handoff contents — Revision 3

**1 October 2026 · Source alignment, not a current scientific release**

The sole forward plan is [UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md](UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md). [START_HERE](START_HERE.md) gives the execution route. [PROJECT_SOURCE_ALIGNMENT.md](PROJECT_SOURCE_ALIGNMENT.md) and [SOURCE_AUTHORITY.json](SOURCE_AUTHORITY.json) define source roles and observed availability.

## What is actually supplied

`source/history/v0.1b/` holds the five original historical files: README, world explanation, framework, mathematical core and status/blockers. `source/history/v0.2-audit/` holds the nine original audit files: README, audit, worked mathematics, proposed next experiment, bibliography, provenance, script, JSON results and CSV results. All fourteen files are unchanged from R2.

`source/project-notes/` holds two labelled visible-text transcriptions of the distinct shared Project notices. The exact attachment IDs disambiguate their identical display title. They report current-package selection and the emergent-interaction update; they are not the current package itself.

`history/UNITY_THEORY_WEBSITE_HANDOFF_R2.zip` is the original complete R2 ZIP, unchanged. It preserves all old forward instructions and evidence as superseded history. Do not mix those instructions into R3.

`evidence/alignment_checks.py` and its JSON result concern this handoff/source-role contract. They do not import or test a production website and do not reproduce the old physics calculation.

## What is not supplied

The actual RRG_CURRENT ZIP/directory, 00_LOCKED_CORE.md, current manifest and current scientific/evidence files were not obtained. The older documents with matching filenames remain older versions. No new placeholder current file was created. The declared full RRG_ARCHIVE_OLD_VERSIONS.zip is also not available; the fourteen retained files are not presented as that complete archive.

No website code/lockfile, rendered browser test, human-comprehension test, verified current-core hash, source-theory rewrite, fresh primary-literature audit, license grant, public repository, domain or live release is included.

## Integrity and review scope

HANDOFF_MANIFEST.json lists final delivered file paths, sizes and SHA-256 values, excluding itself. That manifest proves only the delivered package's internal file identity. SOURCE_AUTHORITY.json separately records the expected core hash and explicitly null actual current hashes. Package integrity cannot satisfy the missing-source gate.

The original files' READMEs and old “current” wording are retained as historical text. Parent path and source role determine their use. This handoff must not be copied wholesale into website public assets or represented as a complete RRG_CURRENT release.
