#!/usr/bin/env python3
"""Check this source-alignment handoff, not a website or the missing RRG_CURRENT.

Default: print a JSON receipt without modifying delivered files.
Optional --output PATH writes a separate receipt; do not overwrite manifest-bound
files in an already sealed bundle. Reference admission cases use synthetic bytes.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import unittest
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_CORE = 'b6d3e7c75285889afe94cabf083ba5fb80f401c656613ba6a80d2f0149b655e1'
EXPECTED = {
    '00_LOCKED_CORE.md','01_world_explanation.md','02_scientific_framework.md',
    '03_mathematical_core.md','04_status_and_blockers.md','05_CHANGE_CONTROL.md',
    '06_PROOF_MATRIX.md','07_EMERGENT_INTERACTION_EVIDENCE.md',
    '08_ADDITIONAL_PRIMARY_EVIDENCE.md','CURRENT_MANIFEST.md'
}
ACTIVE_MD = ['START_HERE.md','PROJECT_SOURCE_ALIGNMENT.md','BUNDLE_INFO.md',
             'UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md']

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def reference_admission(files: dict[str, bytes] | None, *, source_role: str,
                        expected_core: str, manifest: dict[str, str]) -> str:
    """A deliberately small reference contract, not production intake software."""
    if not files:
        return 'CURRENT_SOURCE_PACKAGE_MISSING'
    if source_role != 'owner-designated-current':
        return 'SOURCE_ROLE_REJECTED'
    if not EXPECTED.issubset(files):
        return 'CURRENT_MANIFEST_INCOMPLETE'
    if sha(files['00_LOCKED_CORE.md']) != expected_core:
        return 'LOCKED_CORE_MISMATCH'
    # This synthetic manifest is supplied by the fixture, not an invented parser
    # for the actual unavailable human-readable CURRENT_MANIFEST.md.
    if set(files) != set(manifest):
        return 'CURRENT_MANIFEST_INCOMPLETE'
    if any(sha(data) != manifest[name] for name, data in files.items()):
        return 'CURRENT_MANIFEST_INCOMPLETE'
    return 'SYNTHETIC_CONTRACT_PASS_NOT_CURRENT_SOURCE_QUALIFICATION'

class AlignmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.authority = json.loads((ROOT/'SOURCE_AUTHORITY.json').read_text())
        cls.plan = (ROOT/'UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md').read_text()

    def test_01_current_is_declared_but_not_falsely_obtained(self):
        active=self.authority['active_package']
        self.assertEqual(active['name'],'RRG_CURRENT')
        self.assertEqual(active['availability'],'MISSING_CURRENT_PACKAGE')
        for key in ('actual_manifest_sha256','actual_package_sha256','local_admitted_directory'):
            self.assertIsNone(active[key],key)
        for key in ('currentSourceQualified','legacy_fallback_allowed',
                    'reconstruct_from_summary_allowed','actual_content_acceptance_allowed',
                    'public_release_allowed'):
            self.assertIs(active[key],False,key)

    def test_02_core_pin_is_reported_not_computed(self):
        core=self.authority['active_package']['locked_core']
        self.assertEqual(core['expected_sha256'],EXPECTED_CORE)
        self.assertIsNone(core['actual_sha256'])
        self.assertEqual(core['verification'],'NOT_PERFORMED_MISSING_BYTES')
        self.assertTrue(core['hash_raw_bytes'])
        self.assertFalse(core['automatic_pin_update_allowed'])

    def test_03_all_ten_declared_main_files_are_expected_not_fabricated(self):
        entries=self.authority['active_package']['required_declared_main_files']
        self.assertEqual({v['filename'] for v in entries},EXPECTED)
        self.assertEqual(len(entries),10)
        for v in entries:
            self.assertEqual(v['availability'],'NOT_OBTAINED')
            self.assertIsNone(v['actual_sha256'])
        for path in ('RRG_CURRENT','source/current','source/RRG_CURRENT','research/RRG_CURRENT'):
            self.assertFalse((ROOT/path).exists(),path)

    def test_04_same_title_notices_have_distinct_actual_ids(self):
        entries=self.authority['notice_sources']
        self.assertEqual(len(entries),2)
        self.assertEqual({e['file_id'] for e in entries},{
          'file_0000000047a0820ab6beb4722417cd62',
          'file_000000008550820ab37191709b2c050d'})
        self.assertEqual({e['title'] for e in entries},{'GPT 6.1 overview.txt'})
        for e in entries:
            text=(ROOT/e['path']).read_text()
            self.assertIn(e['file_id'],text)
            self.assertIn(EXPECTED_CORE,text)
            self.assertTrue(e['authorityNoticeOnly'])
            self.assertEqual(e['representation'],'visible_text_transcription')

    def test_05_historical_bytes_match_original_r2_archive(self):
        entries=self.authority['historical_sources']
        self.assertEqual(len(entries),14)
        with zipfile.ZipFile(ROOT/self.authority['superseded_handoff']) as z:
            self.assertIsNone(z.testzip())
            for e in entries:
                data=(ROOT/e['path']).read_bytes()
                self.assertEqual(e['role'],'history_only')
                self.assertEqual(len(data),e['bytes'])
                self.assertEqual(sha(data),e['sha256'])
                legacy=e['path'].replace('source/history/','source/',1)
                self.assertEqual(data,z.read('unity_theory_website_handoff_r2/'+legacy))

    def test_06_active_read_routes_exist_and_no_phantom_current_download(self):
        for name in ACTIVE_MD:
            text=(ROOT/name).read_text()
            self.assertNotIn('](sandbox:/mnt/data/RRG_CURRENT',text)
            for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',text):
                target=target.strip('<>').split('#')[0]
                if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target):
                    continue
                dest=(ROOT/target).resolve()
                self.assertTrue(dest.is_relative_to(ROOT),target)
                self.assertTrue(dest.exists(),f'{name}: {target}')

    def test_07_one_r3_plan_and_all_eight_milestones(self):
        self.assertEqual(self.authority['single_forward_plan'],
                         'UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md')
        self.assertIn('revision: 3\n',self.plan)
        self.assertEqual(re.findall(r'^### (M[0-7]) — ',self.plan,re.M),
                         [f'M{i}' for i in range(8)])
        self.assertIn('Read its current status',self.plan)
        self.assertNotIn('Use UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md Revision 2',self.plan)
        self.assertNotIn('entire relevant Revision 2',self.plan)

    def test_08_source_contract_has_no_legacy_reconstruction_instruction(self):
        for marker in ('CURRENT_SOURCE_PACKAGE_MISSING','LOCKED_CORE_MISMATCH',
                       'CURRENT_MANIFEST_INCOMPLETE','SOURCE_BINDING_FAILURE',
                       'research/RRG_CURRENT/','research/publication/',
                       'authorityNoticeOnly: true','source-scoped',
                       'raw bytes','sidecar','excerptSha256'):
            self.assertIn(marker,self.plan,marker)
        self.assertNotIn('**Requires.** M0 accepted; original and audit sources present.',self.plan)
        self.assertNotIn('Author the single canonical `/framework/` document from the core records.',self.plan)
        self.assertIn('Conditional historical supplement',self.plan)
        self.assertIn('actual current 00/01/02',self.plan)

    def test_09_new_interaction_question_and_beginner_priority_retained(self):
        self.assertIn('life-environment',self.plan)
        self.assertIn('effective-interaction',self.plan)
        self.assertIn('plain-language',self.plan)
        self.assertIn(r'\mathcal I_{n+1}^{\rm eff}',self.plan)
        self.assertIn(r'\rightarrow',self.plan)
        self.assertIn('four fundamental interactions are four successive RRG levels',self.plan)
        self.assertIn('08_ADDITIONAL_PRIMARY_EVIDENCE.md',self.plan)

    def test_10_no_control_char_or_unbalanced_code_fence_in_active_documents(self):
        for name in ACTIVE_MD:
            data=(ROOT/name).read_bytes()
            self.assertNotIn(b'\r',data,name)
            self.assertFalse(any(x<32 and x not in (9,10) for x in data),name)
            text=data.decode('utf-8')
            self.assertEqual(len(re.findall(r'^```',text,re.M))%2,0,name)

    def test_11_historical_numeric_receipts_are_not_fresh_r3_claims(self):
        for marker in ('NOT_RERUN','R3 does not rerun','not a computed hash verification',
                       'not freshly rechecked','Original Project attachments remain original'):
            self.assertIn(marker,self.plan,marker)

    def test_12_source_admission_reference_cases(self):
        data={name:('synthetic fixture only: '+name+'\n').encode() for name in EXPECTED}
        pin=sha(data['00_LOCKED_CORE.md'])
        manifest={name:sha(b) for name,b in data.items()}
        cases=[
          ('missing',None,'owner-designated-current',pin,manifest,'CURRENT_SOURCE_PACKAGE_MISSING'),
          ('history',data,'history_only',pin,manifest,'SOURCE_ROLE_REJECTED'),
          ('notice',data,'authority-notice',pin,manifest,'SOURCE_ROLE_REJECTED'),
          ('wrong core',data,'owner-designated-current','0'*64,manifest,'LOCKED_CORE_MISMATCH'),
          ('missing 08',{k:v for k,v in data.items() if k!='08_ADDITIONAL_PRIMARY_EVIDENCE.md'},
             'owner-designated-current',pin,manifest,'CURRENT_MANIFEST_INCOMPLETE'),
          ('mixed edition',{**data,'07_EMERGENT_INTERACTION_EVIDENCE.md':b'different edition'},
             'owner-designated-current',pin,manifest,'CURRENT_MANIFEST_INCOMPLETE'),
          ('valid synthetic',data,'owner-designated-current',pin,manifest,
             'SYNTHETIC_CONTRACT_PASS_NOT_CURRENT_SOURCE_QUALIFICATION')]
        for name,contents,role,key,seal,result in cases:
            with self.subTest(case=name):
                self.assertEqual(reference_admission(contents,source_role=role,
                      expected_core=key,manifest=seal),result)
        self.assertNotEqual(sha(b'core\n'),sha(b'core\r\n'))
        # Reference fixtures must never qualify the real missing package.
        self.assertFalse(self.authority['active_package']['currentSourceQualified'])

class RecordingResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.receipts=[]
    def addSuccess(self,test):
        super().addSuccess(test)
        self.receipts.append({'test':test.id().split('.')[-1],'outcome':'PASS'})
    def addFailure(self,test,err):
        super().addFailure(test,err)
        self.receipts.append({'test':test.id().split('.')[-1],'outcome':'FAIL'})
    def addError(self,test,err):
        super().addError(test,err)
        self.receipts.append({'test':test.id().split('.')[-1],'outcome':'ERROR'})

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--test',action='append',help='Run only a named AlignmentTests method')
    args=parser.parse_args()
    stream=io.StringIO()
    runner=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordingResult)
    suite=(unittest.TestSuite(AlignmentTests(name) for name in args.test)
           if args.test else unittest.defaultTestLoader.loadTestsFromTestCase(AlignmentTests))
    result=runner.run(suite)
    receipt={
        'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Handoff/source-alignment checks and synthetic admission reference cases only',
        'plan_revision':3,
        'plan_sha256':sha((ROOT/'UNITY_THEORY_WEBSITE_IMPLEMENTATION_PLAN.md').read_bytes()),
        'python':sys.version.split()[0],
        'tests_run':result.testsRun,
        'successful':result.wasSuccessful(),
        'results':result.receipts,
        'log':stream.getvalue(),
        'actual_current_package_obtained':False,
        'actual_core_hash_verified':False,
        'currentSourceQualified':False,
        'research_calculation_rerun':False,
        'website_tests_run':False,
        'original_project_sources_mutated':False,
        'limitations':['Actual RRG_CURRENT unavailable','No production site or browser execution',
                       'No new primary-literature or numerical reproduction check']
    }
    out=json.dumps(receipt,indent=2,ensure_ascii=False)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(out)
    print(out)
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':
    raise SystemExit(main())
