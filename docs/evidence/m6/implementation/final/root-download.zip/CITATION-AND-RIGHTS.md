# Citation and rights

Public credit decision pending.

Permanent URL pending.

No additional license is granted by this preview; license selection is pending.

Code, research prose/figures and data/evidence have separate rights decisions. Third-party rights and lawful exceptions remain applicable. The dependency notice in THIRD-PARTY-NOTICES.txt applies only to KaTeX, not the project.

Research edition: RRG v0.2 locked + evidence updates; promoted 2026-10-01
Website release: site-2026.10.05-m6-private
Source commit: a46d943dd89c543bed15b165835f845c25db0f93
Workspace dirty: true
Input digest: ad625fcd77b1f1ed3e85062211e242d18aa583241399c257ca8847d32a429959
Document manifest: b47ee2a560d581d06a973bee66289a28d34783a6aca787768d3f8c3b2a3c683e
